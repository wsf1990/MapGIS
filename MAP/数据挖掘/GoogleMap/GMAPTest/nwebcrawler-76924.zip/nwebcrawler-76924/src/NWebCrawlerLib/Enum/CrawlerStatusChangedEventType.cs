﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NWebCrawlerLib.Enum
{
    /// <summary>
    /// 工作状态改变类型
    /// </summary>
    public enum CrawlerStatusChangedEventType
    {

    }
}
