﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NWebCrawlerLib.Event
{
    /// <summary>
    /// 下载状态变化
    /// </summary>
    public class DownloaderStatusChangedEventArgs : EventArgs
    {

    }
}
