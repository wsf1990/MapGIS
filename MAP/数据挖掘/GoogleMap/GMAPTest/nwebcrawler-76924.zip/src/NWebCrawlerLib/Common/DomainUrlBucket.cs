﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NWebCrawlerLib.Common
{
    public class DomainUrlBucket
    {
        public Queue<string> UrlQueue = new Queue<string>();
    }
}
